import { Component } from '@angular/core';

@Component({
  selector: 'app-admi-nav-bar',
  templateUrl: './admi-nav-bar.component.html',
  styleUrls: ['./admi-nav-bar.component.css']
})
export class AdmiNavBarComponent {

}
