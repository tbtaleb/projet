import { EmailChangerPipe } from './email-changer.pipe';

describe('EmailChangerPipe', () => {
  it('create an instance', () => {
    const pipe = new EmailChangerPipe();
    expect(pipe).toBeTruthy();
  });
});
