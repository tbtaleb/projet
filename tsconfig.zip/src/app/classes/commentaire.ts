export class Commentaire {
    constructor(
        public idUser: number,
        public text:string,
        public id?: number
    ){}
}
